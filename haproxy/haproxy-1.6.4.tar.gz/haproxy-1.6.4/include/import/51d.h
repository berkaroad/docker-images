#ifndef _IMPORT_51D_H
#define _IMPORT_51D_H

#include <51Degrees.h>

int init_51degrees(void);
void deinit_51degrees(void);

#endif
