# ChangeLog

## 2016.1.18
* 修复不能改写select多张表的bug

## 2015-09-12
### feature
* select操作支持min和max函数表达式。

## 2015-09-07
### feature
* 增加SQL日志输出开关。

## 2015-08-23
### feature
* select操作支持sum和count函数表达式。

## 2015-08-13
### feature
* 支持日志输出到文件。

## 2015-08-09
### feature
* 支持在单node上的事务，不支持跨多个node执行事务。

## 2015-08-08
### feature
* 将sql发送到指定的node。

## 2015-08-04
### feature
* 增加查看proxy配置的命令。

## 2015-08-02
### feature
* 增加管理后端DB的命令。

## 2015-07-26
### feature
* 增加多个slave支持，并且可以设置每个slave的负载权重。
* 完善日志输出格式。

	